/* a bunch of random number generating functions to make life fun fun fun */

void srrand(unsigned);
float rrand();
float brrand();
void tsrand();
float gaussian();
float cauchy();
float linlo();
float linhi();
float triangle();
