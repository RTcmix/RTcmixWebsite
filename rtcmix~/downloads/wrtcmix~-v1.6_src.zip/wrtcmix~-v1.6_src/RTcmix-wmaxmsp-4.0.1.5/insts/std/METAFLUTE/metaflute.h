#define DELSIZE 500
