// PVFilter.C -- base class for pvoc data filters

#include "PVFilter.h"

PVFilter::PVFilter()
{
}

PVFilter::~PVFilter()
{
}
