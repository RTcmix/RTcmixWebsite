#define START 3
#define STARTM1 2 /* for start of comb memory in a array */
#define NCOMBS  6 /* for reverb */
#define NALPASSES 2 /* for reverb */
