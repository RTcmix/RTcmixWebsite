void cfast(float *, long);
void cford1(int, float *);
void cford2(int, float *);
void cfr2tr(long, float *, float *);
void cfr4syn(long, long, float *, float *, float *, float *,
                         float *, float *, float *, float *);
void cfr4tr(long, long, float *, float *, float *, float *,
                        float *, float *, float *, float *);
void cfsst(float *, long);

