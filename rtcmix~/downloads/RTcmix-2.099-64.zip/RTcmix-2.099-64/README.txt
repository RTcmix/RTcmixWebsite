Put this folder in your appropriate Library folder.  (I only have
Max 7, so for me it's in "/Users/Shared/Max 7/Library" -- not sure
where it is in Max 8, but I think it's in "/Users/Shared/Max 8/Library")

