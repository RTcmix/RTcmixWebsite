#define maxdl 14000
typedef struct {
	int p,del;
	float d[maxdl],c1,c2;
	} delayq;
