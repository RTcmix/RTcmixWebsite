/* setup.h */
int get_setup_params(double [], double [12][12], float *, float *, int *,
                                                         double *, double *);

