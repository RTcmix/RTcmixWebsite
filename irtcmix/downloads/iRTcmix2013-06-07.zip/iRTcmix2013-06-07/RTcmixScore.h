//
//  RTcmixScore.h
//
//  Copyright 2009-2013 Brad Garton, Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import <Foundation/Foundation.h>

@interface RTcmixScore : NSObject {
	NSString                *rtScore;
	NSMutableArray				*parsedScore;
	NSMutableDictionary     *parameterValues;
	NSMutableDictionary     *parameterInlets;
	BOOL                    isSetup;
	BOOL							isBangScript;
}

@property (nonatomic, strong)	NSString                *rtScore;
@property (nonatomic, strong)	NSMutableArray				*parsedScore;
@property (nonatomic, strong)	NSMutableDictionary     *parameterValues;
@property (nonatomic, strong)	NSMutableDictionary     *parameterInlets;
@property							BOOL							isSetup;
@property							BOOL							isBangScript;

- (id)initWithNSString:(NSString *)score;
- (void)setupParameters;

@end
