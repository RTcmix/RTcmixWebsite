//
//  MessagesViewController.m
//  iRTcmix Lab
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "MessagesViewController.h"

@implementation MessagesViewController

-(IBAction)goBang {
	// Send a score to RTcmix to make a beep and a MAXBANG at time 0.
	[self.rtcmixManager parseScoreWithNSString:@"print_off() WAVETABLE(0, .2, 24000, 440, .5) MAXBANG(0)"];
}

-(IBAction)toggleBangLoop:(UISwitch *)toggle {
	self.bangLoop = toggle.on;
}

-(IBAction)goMessage {
	// Send a score to RTcmix to send the MAXMESSAGE with the varables used for the instrument. MAXMESSAGES must be numbers.
	[self.rtcmixManager parseScoreWithNSString:@"print_off() freq = irand(220, 440) hardness = random() position = random() preset = irand(8) MMODALBAR(0, .2, 24000, freq, hardness, position, preset)  MAXMESSAGE(0, freq, hardness, position, preset)"];
}

-(IBAction)toggleMessageLoop:(UISwitch *)toggle {
	self.messageLoop = toggle.on;
}

-(IBAction)goError {
	// Clear the error string.
	self.errorMessage = [NSMutableString stringWithString:@""];
	
	// Send a score that contains a print statement and an errror.
	[self.rtcmixManager parseScoreWithNSString:@"print_on(2) print(\"This is a print statement.\") foo = bar"];
}


// RTcmixPlayer delegate methods maxBang, maxMessage:, and maxError:.

-(void)maxBang {
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:@"Bang!" waitUntilDone:NO];
	
	// If bangToggle is on, trigger a similar score, with delayed start time for the beep and the MAXBANG.
	if (self.bangLoop)
	{
		[self.rtcmixManager parseScoreWithNSString:@"MAXBANG(.25) WAVETABLE(.25, .2, 24000, 440, .5)"];
	}
}

-(void)maxMessage:(NSArray *)message {
	NSMutableString *maxMessageMessage = [NSMutableString stringWithString:@"I have a message:\n"];
	
	for (NSNumber *item in message)
	{
		[maxMessageMessage appendFormat:@"%@ ", item];
	}
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:maxMessageMessage waitUntilDone:NO];
	
	// If the messageToggle is on, trigger another score.
	if (self.messageLoop)
	{
		// If bangToggle is on, trigger a similar score, with delayed start time for the instrument and the MAXBANG.
		[self.rtcmixManager parseScoreWithNSString:@"freq = irand(220, 440) hardness = random() position = random() preset = irand(8) MMODALBAR(.25, .2, 24000, freq, hardness, position, preset)  MAXMESSAGE(.25, freq, hardness, position, preset)"];
	}
}

-(void)maxError:(NSString *)error {
	[self.errorMessage appendString:error];
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:self.errorMessage waitUntilDone:NO];
}


-(void)setTextField:(NSString *)text {
	// This method is necessary because changes to the UI have to be done on the main thread and the
	// RTcmixPlayer delegate methods are called from another thread.
	[self.textArea setText:text];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	// Initialize the error message string and loop flags
	self.errorMessage = [NSMutableString stringWithString:@""];
	self.bangLoop = YES;
	self.messageLoop = YES;
	
	// Initialize the RTcmixPlayer. Since audio has already been started in the BasicsViewController,
	// we don't have to do it again. Here we're just giving ourselves a pointer to the singleton object.
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	
	// Set MessagesViewController to be the RTcmixPlayer delegate. This allows us to implement the
	// delegate methods to handle MAXBANG, MAXMESSAGE, and MAXERROR.
	[self.rtcmixManager setDelegate:self];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		self.title = NSLocalizedString(@"Messages", @"Messages");
		self.tabBarItem.image = [UIImage imageNamed:@"messages"];
	}
	return self;
}

@end
