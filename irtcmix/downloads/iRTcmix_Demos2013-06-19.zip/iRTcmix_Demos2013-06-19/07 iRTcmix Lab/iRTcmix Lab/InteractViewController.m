//
//  InteractViewController.m
//  iRTcmix Lab
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "InteractViewController.h"

@implementation InteractViewController

- (IBAction)filterFreqSlide:(UISlider *)sender {
	float freqValue = sender.value;
	NSNumber *freqObject = [NSNumber numberWithFloat:freqValue];
	
	// Store the value in the setupScore then send inlet (realtime control) value.
	[self.setupScore.parameterValues setObject:freqObject forKey:@"filterFreq"];
	[self.rtcmixManager setInlet:1 withValue:freqValue];
	
	[self.filterFreqLabel setText:[NSString stringWithFormat:@"%.2f", freqValue]];
}

- (IBAction)durationSlide:(UISlider *)sender {
	float durationValue = sender.value;
	NSNumber *durationObject = [NSNumber numberWithFloat:durationValue];
	
	// Store the value in the mainScore. This one does not use realtime contol
	// so you do not call setInlet:withValue like is does for filterFreqSlide.
	[self.mainScore.parameterValues setObject:durationObject forKey:@"dur"];
	
	[self.durationLabel setText:[NSString stringWithFormat:@"%.2f", durationValue]];
}

-(IBAction)goScore {
	// Send the score to RTcmix to make some noise!
	[self.rtcmixManager parseScoreWithRTcmixScore:self.mainScore];
}

- (void)viewWillAppear:(BOOL)animated {
	// Run the setup score.
	[self.rtcmixManager parseScoreWithRTcmixScore:self.setupScore];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	// Initialize the RTcmixPlayer. Since audio has already been started in the BasicsViewController,
	// we don't have to do it again. Here we're just giving ourselves a pointer to the singleton object.
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	
	// In Basics and Soundfiles, we stored simple scripts in NSStrings and ran then using the
	// method rtcmixManager:parseScoreWithNSString. In this example, we are loading scores from files
	// and saving them using the RTcmixScore class which stores the score text plus allows us to use
	// variables that we can easily set just before score parsing time. Scores are then sent to run
	// using the method rtcmixManager:parseScoreWithRTcmixScore.
	
	// Load the "setup" score from the file Interact_Setup.sco. This contains a score that only needs
	// to run once. It is set to run in the viewWillAppear:animated method. It's not run here in the
	// viewDidLoad method since a flush commannd sent from the Basics section will flush this score too
	// so we have to make sure it's running when we get to this tab.
	NSString *setupScorePath = [[NSBundle mainBundle] pathForResource:@"Interact_Setup" ofType:@"sco"];
	NSString *setupScoreText = [NSString stringWithContentsOfFile:setupScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"Interact_Setup" withString:setupScoreText];
	
	// Load the "main" score from the file Interact_Main.sco. This is the score that will run when
	// the user presses the "Go!" button.
	NSString *mainScorePath = [[NSBundle mainBundle] pathForResource:@"Interact_Main" ofType:@"sco"];
	NSString *mainScoreText = [NSString stringWithContentsOfFile:mainScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"Interact_Main" withString:mainScoreText];
	
	// Store pointers to the scores we just added to the rtcmixManager.
	self.setupScore = [self.rtcmixManager.scoreDict objectForKey:@"Interact_Setup"];
	self.mainScore = [self.rtcmixManager.scoreDict objectForKey:@"Interact_Main"];
	
	// Initialize default values.
	[self.mainScore.parameterValues setObject:[NSNumber numberWithFloat:.25] forKey:@"dur"];
	[self.mainScore.parameterValues setObject:[NSNumber numberWithBool:NO] forKey:@"loopToggle"];
	[self.setupScore.parameterValues setObject:[NSNumber numberWithFloat:4000.0] forKey:@"filterFreq"];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		self.title = NSLocalizedString(@"Interact", @"Interact");
		self.tabBarItem.image = [UIImage imageNamed:@"interact"];
	}
	return self;
}

@end
