//
//  ViewController.m
//  Audio Input
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"

@implementation ViewController

-(IBAction)goEcho {
	// play the score - watch out for feedback!
	[self.rtcmixManager parseScoreWithNSString:@"rtinput(\"AUDIO\") PANECHO(0, 0, 99999, 0.3, 0.3, 0.8, 0.3, 3.5, 0) PANECHO(0, 0, 99999, 0.3, 0.3, 0.8, 0.3, 3.5, 1)"];
}

-(IBAction)flush {
	// stop all running scores
	[self.rtcmixManager flushAllScripts];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	// NOTE: audio input does not work in the simulator - you must run it on an iDevice
	// initialize the RTcmixPlayer, set the audio input flag, and start audio
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	self.rtcmixManager.audioInputFlag = YES;
	[self.rtcmixManager startAudio];
}

@end
