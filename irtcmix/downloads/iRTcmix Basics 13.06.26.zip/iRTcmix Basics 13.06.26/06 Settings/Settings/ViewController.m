//
//  ViewController.m
//  Settings
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"


@implementation ViewController


-(IBAction)goBeep {
	// send the score to RTcmix to make some noise
	[self.rtcmixManager parseScoreWithNSString:@"bus_config(\"WAVETABLE\",\"out 0-1\") WAVETABLE(0, 100, 24000, 440, .5)"];
}

-(IBAction)goEcho {
	// send the score to RTcmix to make some noise
	[self.rtcmixManager parseScoreWithNSString:@"rtinput(\"AUDIO\") PANECHO(0, 0, 99999, 0.3, 0.3, 0.8, 0.3, 3.5, 0) PANECHO(0, 0, 99999, 0.3, 0.3, 0.8, 0.3, 3.5, 1)"];
}

-(IBAction)flushAll {
	// stop all running scripts
	[self.rtcmixManager flushAllScripts];
}

-(IBAction)toggleAudioInput:(UISwitch *)toggle {
	// NOTE: audio input does not work in the simulator - you must run it on an iDevice
	// show the echo button only if audio-in is turned on
	if (toggle.on)
		self.echoButton.hidden = NO;
	else
		self.echoButton.hidden = YES;
	
	// set the audio input flag to refect new status
	self.rtcmixManager.audioInputFlag = toggle.on;
	
	// reset the audio settings.
	[self.rtcmixManager resetAudio];
}

-(IBAction)toggleBackgroundMode:(UISwitch *)toggle {
	// NOTE: background audio does not work in the simulator - you must run it on an iDevice
	// in order for this to work, "App plays audio" is set in the "Required background modes"
	// of iRTcmix Lab-Info.plist
	
	// also see the applicationDidEnterBackground: & applicationWillEnterForeground: of
	// AppDelegate.m to see where audio pausing and restarting is called.
	self.rtcmixManager.shouldRunInBackground = toggle.on;
}

- (void)viewDidLoad {
    [super viewDidLoad];

	// hide the echo button since we start with audio-in off
	self.echoButton.hidden = YES;

	// initialize the RTcmixPlayer
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	
	// set the vector size - value must be a power of 2
	// higher values will tax the CPU somewhat less at the expense of increased latency
	// setting this is optional - if it is not set explicitly it will default to 512
	// [note: this must be set before you call startAudio and may not be changed after]
	self.rtcmixManager.vectorSize = 1024;
	
	// start audio
	[self.rtcmixManager startAudio];
}


@end
