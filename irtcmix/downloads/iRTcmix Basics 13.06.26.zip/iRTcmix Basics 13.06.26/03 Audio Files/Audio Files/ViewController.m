//
//  ViewController.m
//  Audio Files
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"

@implementation ViewController

- (IBAction)playLoocherBuffer {
	// set values of the variables
	// the RTcmixScore class looks for variables in the score that are assigned a value of "%#"
	// these variables can then be assigned values from your app - as in the next two lines
	[self.bufferScore.parameterValues setObject:@"\"Loocher\"" forKey:@"buffer"];
	[self.bufferScore.parameterValues setObject:[NSNumber numberWithFloat:9.971] forKey:@"length"];
	
	// play from a pre-loaded buffer
	[self.rtcmixManager parseScoreWithRTcmixScore:self.bufferScore];
}

- (IBAction)playSheepBuffer {
	// set values of the variables
	// the RTcmixScore class looks for variables in the score that are assigned a value of "%#"
	// these variables can then be assigned values from your app - as in the next two lines
	[self.bufferScore.parameterValues setObject:@"\"Sheep\"" forKey:@"buffer"];
	[self.bufferScore.parameterValues setObject:[NSNumber numberWithFloat:8.895] forKey:@"length"];

	// play from a pre-loaded buffer
	[self.rtcmixManager parseScoreWithRTcmixScore:self.bufferScore];
}

- (IBAction)playJackhammerFile {	
	// set values of the variables
	// the RTcmixScore class looks for variables in the score that are assigned a value of "%#"
	// these variables can then be assigned values from your app - as in the next two lines
	[self.soundfileScore.parameterValues setObject:[NSString stringWithFormat:@"\"%@\"", self.jackhammerPath] forKey:@"path"];
	[self.soundfileScore.parameterValues setObject:[NSNumber numberWithFloat:17.63] forKey:@"length"];
	
	// play from "disk"
	[self.rtcmixManager parseScoreWithRTcmixScore:self.soundfileScore];
}

- (IBAction)playRiverFile {	
	// set values of the variables
	// the RTcmixScore class looks for variables in the score that are assigned a value of "%#"
	// these variables can then be assigned values from your app - as in the next two lines
	[self.soundfileScore.parameterValues setObject:[NSString stringWithFormat:@"\"%@\"", self.riverPath] forKey:@"path"];
	[self.soundfileScore.parameterValues setObject:[NSNumber numberWithFloat:6.852] forKey:@"length"];
	
	// play from "disk"
	[self.rtcmixManager parseScoreWithRTcmixScore:self.soundfileScore];
}

- (IBAction)flush {
	// stop all running scores
	[self.rtcmixManager flushAllScripts];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	// initialize the RTcmixPlayer and start audio
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	[self.rtcmixManager startAudio];
	
	// load the buffer score from the file BufferScore.sco
	NSString *bufferScorePath = [[NSBundle mainBundle] pathForResource:@"BufferScore" ofType:@"sco"];
	NSString *bufferScoreText = [NSString stringWithContentsOfFile:bufferScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"BufferScore" withString:bufferScoreText];
	
	// load the soundfile score from the file SoundFileScore.sco
	NSString *soundfileScorePath = [[NSBundle mainBundle] pathForResource:@"SoundFileScore" ofType:@"sco"];
	NSString *soundfileScoreText = [NSString stringWithContentsOfFile:soundfileScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"SoundFileScore" withString:soundfileScoreText];
	
	self.bufferScore = [self.rtcmixManager.scoreDict objectForKey:@"BufferScore"];
	self.soundfileScore = [self.rtcmixManager.scoreDict objectForKey:@"SoundFileScore"];
	
	// save the path information for the soundfile files
	self.jackhammerPath = [[NSBundle mainBundle] pathForResource:@"AdamsJackhammer" ofType:@"aif"];
	self.riverPath = [[NSBundle mainBundle] pathForResource:@"River" ofType:@"aif"];
	
	// pre-load the buffer files
	NSString *loocherSoundPath = [[NSBundle mainBundle] pathForResource:@"loocher441" ofType:@"aif"];
	[self.rtcmixManager setSampleBuffer:@"Loocher" withSoundFile:loocherSoundPath];
	NSString *sheepSoundPath = [[NSBundle mainBundle] pathForResource:@"Sheep" ofType:@"aif"];
	[self.rtcmixManager setSampleBuffer:@"Sheep" withSoundFile:sheepSoundPath];
}

@end
