//
//  ViewController.m
//  Hello iRTcmix
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

-(IBAction)goBeepScore {
	// method 2 to play a score - parseScoreWithNSString:
	[self.rtcmixManager parseScoreWithNSString:@"WAVETABLE(0, 5, 24000, 440, .5)"];
}

-(IBAction)goPlingScore {
	// method 1 to play a score - parseScoreWithRTcmixScore:
	[self.rtcmixManager parseScoreWithRTcmixScore:self.beepScore];
}

-(IBAction)flush {
	// stop all running scores
	[self.rtcmixManager flushAllScripts];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	// initialize the RTcmixPlayer and start audio.
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	[self.rtcmixManager startAudio];

	// load the score from the file HelloiRTcmix.sco and assign it to beepScore
	NSString *scorePath = [[NSBundle mainBundle] pathForResource:@"HelloiRTcmix" ofType:@"sco"];
	NSString *scoreText = [NSString stringWithContentsOfFile:scorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"helloScore" withString:scoreText];
	
	self.beepScore = [self.rtcmixManager.scoreDict objectForKey:@"helloScore"];
}

@end
