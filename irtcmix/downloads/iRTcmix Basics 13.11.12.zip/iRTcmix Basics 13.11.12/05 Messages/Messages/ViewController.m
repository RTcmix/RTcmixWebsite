//
//  ViewController.m
//  Messages
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"

@implementation ViewController

-(IBAction)goBang {
	// a score that sends messages back to the app using MAXBANG
	// send a score to RTcmix to make a beep and a MAXBANG at time 0
	[self.rtcmixManager parseScoreWithNSString:@"print_off() WAVETABLE(0, .2, 24000, 440, .5) MAXBANG(0)"];
}

-(IBAction)toggleBangLoop:(UISwitch *)toggle {
	// set the new toggle value
	self.bangLoop = toggle.on;
}

-(IBAction)goMessage {
	// a score that sends messages back to the app using MAXMESSAGE
	// send a score to RTcmix to send the MAXMESSAGE with the varables used for the instrument
	// MAXMESSAGES must be numbers
	[self.rtcmixManager parseScoreWithNSString:@"print_off() freq = irand(220, 440) hardness = random() position = random() preset = irand(8) MMODALBAR(0, .2, 24000, freq, hardness, position, preset)  MAXMESSAGE(0, freq, hardness, position, preset)"];
}

-(IBAction)toggleMessageLoop:(UISwitch *)toggle {
	self.messageLoop = toggle.on;
}

-(IBAction)goError {
	// clear the error string
	self.errorMessage = [NSMutableString stringWithString:@""];

	// a score that sends messages back to the app using print() plus triggers an error message from the RTcmix parser
	// send a score that contains a print statement and an error
	//[self.rtcmixManager parseScoreWithNSString:@"print_on(2) print(\"This is a print statement.\") foo = bar"];
	//[self.rtcmixManager parseScoreWithNSString:@"print_on(3)\n foo = bar"];
	
	[self.rtcmixManager parseScoreWithRTcmixScore:[self.rtcmixManager.scoreDict objectForKey:@"scoredScore"]];

	
	// the argument given to print_on() determines the types of messages that will be sent by the RTcmix parser
	// 0 -- fatal errors
	// 1 -- print() and printf()
	// 2 -- rterrors
	// 3 -- warn errors
	// 4 -- advise notifications
	// 5 -- all the rest
}


// RTcmixPlayer delegate methods maxBang, maxMessage:, and maxError:
// these are the three different methods for the app to receive messages from a score

-(void)maxBang {
	// this delegate method receives the MAXBANG messages
	
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:@"Bang!" waitUntilDone:NO];
	
	// if bangToggle is on, trigger a similar score, with delayed start time for the beep and the MAXBANG.
	if (self.bangLoop)
	{
		[self.rtcmixManager parseScoreWithNSString:@"MAXBANG(.25) WAVETABLE(.25, .2, 24000, 440, .5)"];
	}
}

-(void)maxMessage:(NSArray *)message {
	// this delegate method receives the MAXMESSAGE messages
	
	NSMutableString *maxMessageMessage = [NSMutableString stringWithString:@"I have a message:\n"];
	
	for (NSNumber *item in message)
	{
		[maxMessageMessage appendFormat:@"%@ ", item];
	}
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:maxMessageMessage waitUntilDone:NO];
	
	// if messageLoop is on, trigger a similar score, with delayed start time for the instrument and the MAXMESSAGE
	if (self.messageLoop)
	{
		[self.rtcmixManager parseScoreWithNSString:@"freq = irand(220, 440) hardness = random() position = random() preset = irand(8) MMODALBAR(.25, .2, 24000, freq, hardness, position, preset)  MAXMESSAGE(.25, freq, hardness, position, preset)"];
	}
}

-(void)maxError:(NSString *)error {
	// this delegate method receives the print() messages and error messages from the RTcmix parser

	[self.errorMessage appendString:error];
	[self performSelectorOnMainThread:@selector(setTextField:) withObject:self.errorMessage waitUntilDone:NO];
}


-(void)setTextField:(NSString *)text {
	// this method is necessary because changes to the UI have to be done on the main thread and the
	// RTcmixPlayer delegate methods are called from another thread
	[self.textArea setText:text];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	// initialize the error message string and loop flags
	self.errorMessage = [NSMutableString stringWithString:@""];
	self.bangLoop = YES;
	self.messageLoop = YES;

	// initialize the RTcmixPlayer and start audio
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	[self.rtcmixManager startAudio];
	
	// set MessagesViewController to be the RTcmixPlayer delegate
	// this allows us to implement the delegate methods to handle MAXBANG, MAXMESSAGE, and MAXERROR from RTcmix scores.
	[self.rtcmixManager setDelegate:self];
	
	
	// load the score from the file HelloiRTcmix.sco and assign it to beepScore
	NSString *scorePath = [[NSBundle mainBundle] pathForResource:@"Scored" ofType:@"sco"];
	NSString *scoreText = [NSString stringWithContentsOfFile:scorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"scoredScore" withString:scoreText];
	
	
}



@end
