//
//  AppDelegate.m
//  Settings
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "AppDelegate.h"

#import "ViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
   
	// initiallize the RTcmixPlayer
	// since it is a singleton class, there will only ever be one (shared) instance of this class
	self.rtcmixManager = [RTcmixPlayer sharedManager];

	self.viewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
	self.window.rootViewController = self.viewController;
	[self.window makeKeyAndVisible];
	return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// if background mode is not enabled, pause the audio when the app enters the background
	if (!self.rtcmixManager.shouldRunInBackground)
		[self.rtcmixManager pauseAudio];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// if background mode is not enabled (and thus audio would still be playing), restart the audio when the app
	// re-enters the foreground
	if (!self.rtcmixManager.shouldRunInBackground)
		[self.rtcmixManager resumeAudio];
}

@end
