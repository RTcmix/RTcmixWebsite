//
//  RTcmixPlayer.m
//
//  Copyright 2009-2013 Brad Garton, Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#include <AudioToolbox/AudioToolbox.h>
#import "RTcmixPlayer.h"

//static RTcmixPlayer *sharedSingletonManager = nil;

@implementation RTcmixPlayer


#pragma mark Setup

- (void)startAudio {
	// Set default values if they haven't already been setup.
	if (!self.volume)
		self.volume = 1.0;
	if (!self.numberOfChannels)
		self.numberOfChannels = 2;
	if (!self.sampleRate)
		self.sampleRate = 44100.0;
	if (!self.vectorSize)
		self.vectorSize = 512; // increase this (in powers of 2) to improve performance (at the expense of latency)
	
	AudioSessionInitialize(NULL, NULL, interruptionListenerCallback, (__bridge void *)(self));
	AudioSessionSetActive(true);
	
	[self setupAudioSession];
	
	rtcmixmain();
	maxmsp_rtsetparams(self.audioFormat.mSampleRate, self.audioFormat.mChannelsPerFrame, self.vectorSize, NULL, NULL);
	
	
	AudioOutputUnitStart(self.rioUnit);
	
	
}

- (void)resetAudio {
	[self flushAllScripts];
	[self pauseAudio];
	[self setupAudioSession];
	AudioOutputUnitStart(self.rioUnit);
}

- (void)setupAudioSession {
#define kOutputBus 0
#define kInputBus 1
	
	//	set the audio session category
	UInt32 sessionCategory;
	if (self.audioInputFlag == 1)
		sessionCategory = kAudioSessionCategory_PlayAndRecord;
	else
		sessionCategory = kAudioSessionCategory_MediaPlayback;
	
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory,
									sizeof(sessionCategory),
									&sessionCategory);
	
	self.preferredBufferSize = (1 / self.sampleRate) * self.vectorSize;
	AudioSessionSetProperty(kAudioSessionProperty_PreferredHardwareIOBufferDuration,
									sizeof(self.preferredBufferSize), &_preferredBufferSize);
	
	// add a property listener to check for changes in audio route
	AudioSessionAddPropertyListener(kAudioSessionProperty_AudioRouteChange,
											  propertyListenerCallback,
											  (__bridge void *)(self));
	
	// if audio is routed to receiver, change it to the speaker
	UInt32 routeSize = sizeof (CFStringRef);
	CFStringRef route;
	AudioSessionGetProperty (kAudioSessionProperty_AudioRoute,
									 &routeSize,
									 &route);
	NSString* currentRoute = (__bridge NSString*)route;
	if ([currentRoute isEqualToString:@"ReceiverAndMicrophone"])
	{
		UInt32 newRoute = kAudioSessionOverrideAudioRoute_Speaker;
		AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute,
										sizeof(newRoute),
										&newRoute);
	}
	
	UInt32 allowMixing = 1;
	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryMixWithOthers,
									sizeof(allowMixing),
									&allowMixing);
	
	// Describe audio component
	AudioComponentDescription desc;
	desc.componentType			= kAudioUnitType_Output;
	desc.componentSubType		= kAudioUnitSubType_RemoteIO;
	desc.componentFlags			= 0;
	desc.componentFlagsMask		= 0;
	desc.componentManufacturer = kAudioUnitManufacturer_Apple;
	
	// Get component
	AudioComponent inputComponent = AudioComponentFindNext(NULL, &desc);
	AudioComponentInstanceNew(inputComponent, &_rioUnit);
	
	// Enable IO for recording
	UInt32 inputFlag = self.audioInputFlag;
	AudioUnitSetProperty(self.rioUnit,
								kAudioOutputUnitProperty_EnableIO,
								kAudioUnitScope_Input,
								kInputBus,
								&inputFlag,
								sizeof(inputFlag));
	
	// Enable IO for playback
	UInt32 outputFlag = 1;
	AudioUnitSetProperty(self.rioUnit,
								kAudioOutputUnitProperty_EnableIO,
								kAudioUnitScope_Output,
								kOutputBus,
								&outputFlag,
								sizeof(outputFlag));
	
	
	_audioFormat.mSampleRate			= self.sampleRate;
	_audioFormat.mFormatID				= kAudioFormatLinearPCM;
	_audioFormat.mFormatFlags			= kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
	_audioFormat.mChannelsPerFrame	= self.numberOfChannels;
	_audioFormat.mBytesPerFrame		= self.numberOfChannels*2; // assumes 16-bit samples, 2 bytes
	_audioFormat.mBitsPerChannel		= 16;
	_audioFormat.mFramesPerPacket		= 1;
	_audioFormat.mBytesPerPacket		= self.audioFormat.mBytesPerFrame * self.audioFormat.mFramesPerPacket;
	_audioFormat.mReserved				= 0;
	
	// Apply format
	if (self.audioInputFlag == 1)
	{
		AudioUnitSetProperty(self.rioUnit,
									kAudioUnitProperty_StreamFormat,
									kAudioUnitScope_Output,
									kInputBus,
									&_audioFormat,
									sizeof(_audioFormat));
	}
	AudioUnitSetProperty(self.rioUnit,
								kAudioUnitProperty_StreamFormat,
								kAudioUnitScope_Input,
								kOutputBus,
								&_audioFormat,
								sizeof(_audioFormat));
	
	// Set output callback
	AURenderCallbackStruct callbackStruct;
	callbackStruct.inputProc = rtcmixPerformCallback;
	callbackStruct.inputProcRefCon = (__bridge void *)(self);
	AudioUnitSetProperty(self.rioUnit,
								kAudioUnitProperty_SetRenderCallback,
								kAudioUnitScope_Global,
								kOutputBus,
								&callbackStruct,
								sizeof(callbackStruct));
	
	// Initialise
	AudioUnitInitialize(self.rioUnit);
	
	if (self.rtcmixOutputBuffer == NULL)
	{
		self.outputBufferIndex = self.vectorSize * self.numberOfChannels; // set at max to get a pullTraverse() straightaway
		self.rtcmixOutputBuffer = malloc(self.vectorSize * self.numberOfChannels * sizeof(short));
	}
	
	if (self.rtcmixInputBuffer == NULL)
	{
		self.inputBufferIndex = self.vectorSize * self.numberOfChannels;
		self.rtcmixInputBuffer = malloc(self.vectorSize * self.numberOfChannels * sizeof(short));
		memset((void *)self.rtcmixInputBuffer, 0, self.vectorSize * self.numberOfChannels * sizeof(short));
	}
}

#pragma mark Audio Utility

- (void) pauseAudio {
	AudioOutputUnitStop(self.rioUnit);
}

- (void) resumeAudio {
	UInt32 sessionCategory;
	sessionCategory = kAudioSessionCategory_MediaPlayback;
	if (self.audioInputFlag == 1)
		sessionCategory = kAudioSessionCategory_PlayAndRecord;
	
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory,
									sizeof (sessionCategory),
									&sessionCategory);
	AudioSessionSetActive(true);
	AudioOutputUnitStart(self.rioUnit);
}

- (void)setVolumeLevel:(float)newvolume {
	//AudioUnitSetParameter(rioUnit, kHALOutputParam_Volume, kAudioUnitScope_Global, 0, volume, 0);
	self.volume = newvolume;
}

#pragma mark Data and Communication

// soundfileplayback from memory
- (int)setSampleBuffer:(NSString *)bufferName withSoundFile:(NSString *)soundFileName {
	AudioFileID     soundFile;
	AudioStreamBasicDescription		dataFormat;
	OSStatus status;
	UInt32 propsize;
	
	void *sampleBuffer;
	float *floatSampleBuffer;
	
	NSString *soundFilePath = [[NSBundle mainBundle]pathForResource:soundFileName ofType:NULL];
	NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
	
	// BGG -- should probably use ExtAudioFileOpenURL()
	status = AudioFileOpenURL((__bridge CFURLRef)soundFileURL, kAudioFileReadPermission, kAudioFileAIFFType, &soundFile);
	if (status != 0)
	{
		NSLog(@"error opening soundfile");
		return 0;
	}
	
	propsize = sizeof(dataFormat);
	status = AudioFileGetProperty(soundFile, kAudioFilePropertyDataFormat, &propsize, &dataFormat);
	if (status != 0)
	{
		NSLog(@"problem getting AudioFile properties");
		return 0;
	}
	
	//Get file size
	UInt64 outDataSize = 0;
	propsize = sizeof(UInt64);
	AudioFileGetProperty(soundFile, kAudioFilePropertyAudioDataByteCount,
								&propsize, &outDataSize);
	
	//Get packet count
	UInt64 outPackets = 0;
	propsize = sizeof(UInt64);
	AudioFileGetProperty(soundFile, kAudioFilePropertyAudioDataPacketCount,
								&propsize, &outPackets);
	
	UInt32 numBytes = outDataSize;
	UInt32 numPackets = outPackets;
	sampleBuffer = malloc(outDataSize);
	if (sampleBuffer == NULL)
	{
		NSLog(@"error mallocing sample buffer");
		return 0;
	}
	
	status = AudioFileReadPackets (soundFile, false, &numBytes, NULL, 0, &numPackets, sampleBuffer);
	if (status !=0)
	{
		NSLog(@"problem reading file packets into buffer");
		return 0;
	}
	
	floatSampleBuffer = malloc(numPackets*dataFormat.mChannelsPerFrame*sizeof(float));
	if (floatSampleBuffer == NULL)
	{
		NSLog(@"error mallocing fsample buffer");
		return 0;
	}
	
	// convert to floating-point buffer for RTcmix
	float *fsbptr = floatSampleBuffer;
	short *sbptr = sampleBuffer;
	for(int i = 0; i < (numPackets*dataFormat.mChannelsPerFrame); i++) {
		sbptr[i] = CFSwapInt16(sbptr[i]);
		fsbptr[i] = (float)sbptr[i]/32768.0;
	}
	
	buffer_set((char *)[bufferName UTF8String], fsbptr, numPackets, dataFormat.mChannelsPerFrame, 0);
	
	return 1;
}

// use this to get data in via the makeconnection() PField scheme
- (void) setInlet:(int)inlet withValue:(Float32)value {
	pfield_set(inlet, value);
}

// maxBang and maxMessage is called from within the playbackCallback(),
// set by MAXBANG() and MAXMESSAGE() in the score
- (void)maxBang {
	@autoreleasepool {
		[self.delegate maxBang];
	}
}

- (void)maxMessage {
	// maxmessage_nvals == number of elements in the returned array h
	// maxmessage_vals[] == an array of floats with the vals
	@autoreleasepool {
		NSMutableArray * maxMessage_Vals = [[NSMutableArray alloc] initWithCapacity: maxmessage_nvals];
		for (int i=0; i < maxmessage_nvals; i++)
		{
			[maxMessage_Vals addObject:[NSNumber numberWithFloat:maxmessage_vals[i]]];
		}
		[self.delegate maxMessage:maxMessage_Vals];
	}
}

- (void)maxError:(char *)message {
	@autoreleasepool {
		[self.delegate maxError:[NSString stringWithFormat:@"%s" , message]];
	}
	
}

// stop all scheduled scripts
- (void)flushAllScripts {
	flush_sched();
}

#pragma mark Score

- (void)addScore:(NSString *)name withString:(NSString *)score {
	RTcmixScore *newScore = [[RTcmixScore alloc] initWithNSString:score];
	if (!self.scoreDict)
		self.scoreDict = [[NSMutableDictionary alloc] init];
	[self.scoreDict setObject:newScore forKey:name];
}

- (void)parseScoreWithNSString:(NSString *)score {
	char cScore[32768];
	strcpy (cScore, [score UTF8String]);
	parse_score(cScore, strlen(cScore));
}

- (void)parseScoreWithRTcmixScore:(RTcmixScore *)score {
	NSMutableString *scoreParsed = [[NSMutableString alloc] init];
	
	for (NSString *line in score.parsedScore)
	{
		NSString *replacementValue = [score.parameterValues objectForKey:line];
		if (replacementValue != nil)
			[scoreParsed appendString:[NSString stringWithFormat:@"%@", replacementValue]];
		else
			[scoreParsed appendString:line];
	}
	
	char mainCScore[32768];
	strcpy (mainCScore,[scoreParsed UTF8String]);
	parse_score(mainCScore, strlen(mainCScore));
}

#pragma mark Singleton

+(id)sharedManager
{
	static dispatch_once_t pred;
	static RTcmixPlayer *sharedSingletonManager = nil;
	dispatch_once(&pred, ^{
		sharedSingletonManager = [[RTcmixPlayer alloc] init];
	});
	return sharedSingletonManager;
}

- (void) dealloc {
	abort();
}

#pragma mark Playback and Interrupt Callbacks

static OSStatus	rtcmixPerformCallback (void								*inRefCon,
													  AudioUnitRenderActionFlags 	*ioActionFlags,
													  const AudioTimeStamp			*inTimeStamp,
													  UInt32								inBusNumber,
													  UInt32								inNumberFrames,
													  AudioBufferList					*ioData) {
	
	RTcmixPlayer *player = (__bridge RTcmixPlayer *) inRefCon;
	
	AudioUnitRender([player rioUnit], ioActionFlags, inTimeStamp, 1, inNumberFrames, ioData);
	
	// these buffers are used because RTcmix is working asynch with the AudioUnit
	short *rtcmixoutptr = player.rtcmixOutputBuffer; // pointers to the bufs we use
	short *rtcmixinptr = player.rtcmixInputBuffer;
	
	//loop through all the buffers that need to be filled
	for (int i = 0 ; i < ioData->mNumberBuffers; i++){
		//get the buffer to be filled
		AudioBuffer buffer = ioData->mBuffers[i];
		UInt16 *frameBuffer = buffer.mData;
		
		//loop through the buffer and fill the frames
		for (int j = 0; j < inNumberFrames * player.numberOfChannels; j += player.numberOfChannels)
		{
			for (int k = 0; k < player.numberOfChannels; k++)
			{
				if(player.outputBufferIndex >= player.vectorSize * player.numberOfChannels)
				{
					pullTraverse(rtcmixinptr, rtcmixoutptr);
					
					// check for retriggering, set by "MAXBANG" in the score
					if (check_bang() == 1)
						[player maxBang];
					
					// check for messages, set by "MAXMESSAGE" in the score
					maxmessage_nvals = check_vals(maxmessage_vals);
					if (maxmessage_nvals)
						[player maxMessage];
					
					// check for print (with the print() commamnd) and error messages from RTcmix
					char *pbuf = get_print();
					char *pbufptr = pbuf;
					while (strlen(pbufptr) > 0)
					{
						[player maxError:pbufptr];
						pbufptr += (strlen(pbufptr) + 1);
					}
					reset_print();
					
					player.outputBufferIndex = 0;
					player.inputBufferIndex = 0;
				}
				rtcmixinptr[player.inputBufferIndex+k] = frameBuffer[j+k];
				
				frameBuffer[j+k] = rtcmixoutptr[player.outputBufferIndex+k] * player.volume;
			}
			player.outputBufferIndex += player.numberOfChannels;
			player.inputBufferIndex += player.numberOfChannels;
		}
	}
	
	return noErr;
}

void interruptionListenerCallback (void		*inUserData,
											  UInt32		interruptionState) {
	RTcmixPlayer *player = (__bridge RTcmixPlayer *) inUserData;
	if (interruptionState == kAudioSessionBeginInterruption)
		[player pauseAudio];
	else if (interruptionState == kAudioSessionEndInterruption)
		[player resumeAudio];
}

void propertyListenerCallback(void *							inClientData,
										AudioSessionPropertyID		inID,
										UInt32							inDataSize,
										const void *					inData) {
	RTcmixPlayer *player = (__bridge RTcmixPlayer *) inClientData;
	if (inID == kAudioSessionProperty_AudioRouteChange)
	{
		// if there was a route change, we need to dispose the current rio unit and create a new one
		AudioComponentInstanceDispose([player rioUnit]);
		[player setupAudioSession];
		AudioOutputUnitStart([player rioUnit]);
	}
}

@end
