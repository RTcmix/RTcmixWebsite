//
//  RTcmixPlayer.h
//
//  Copyright 2009-2013 Brad Garton, Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#include <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIKit.h>
#import "RTcmixScore.h"

// RTcmix external functions called from the RTcmixPlayer
extern int	maxmsp_rtsetparams(float sr, int nchans, int vecsize, float *mm_inbuf, float *mm_outbuf);
extern void pullTraverse(short *inbuf, short *outbuf);
extern int	check_bang();
extern void pfield_set(int inlet, float pval);
extern void buffer_set(char *bufname, float *bufstart, int nframes, int nchans,
							  int modtime);
extern int	rtcmixmain();
extern int	parse_score(char *thebuf, int buflen);
extern void flush_sched();
extern int	check_vals(float *thevals);
extern char *get_print();
extern void reset_print();
int			maxmessage_nvals;
float			maxmessage_vals[1024];

@protocol RTcmixPlayerDelegate;

@interface RTcmixPlayer : NSObject

@property (nonatomic, unsafe_unretained) id <RTcmixPlayerDelegate> delegate;

@property (readwrite)			AudioStreamBasicDescription	audioFormat;
@property (readwrite)			short									*rtcmixOutputBuffer;
@property (readwrite)			int									outputBufferIndex;
@property (readwrite)			short									*rtcmixInputBuffer;
@property (readwrite)			int									inputBufferIndex;
@property (nonatomic, assign)	AudioUnit							rioUnit;

@property (readwrite)			CGFloat								sampleRate;
@property (readwrite)			NSInteger							vectorSize;
@property (readwrite)			NSInteger							numberOfChannels;
@property (readwrite)			CGFloat								preferredBufferSize;
@property (readwrite)			BOOL									audioInputFlag;
@property (readwrite)			BOOL									shouldRunInBackground;
@property (readwrite)			CGFloat								volume;

@property (nonatomic, strong)	NSMutableDictionary				*scoreDict;

// Setup
- (void)startAudio;
- (void)resetAudio;
- (void)setupAudioSession;

// Audio Utility
- (void)pauseAudio;
- (void)resumeAudio;
- (void)setVolumeLevel:(float)newvolume;

// Data and Communication
- (int)setSampleBuffer:(NSString *)bufferName withSoundFile:(NSString *)soundFileName;
- (void)setInlet:(int)inlet withValue:(Float32)value;
- (void)maxBang;
- (void)maxMessage;
- (void)maxError:(char *)message;
- (void)flushAllScripts;

// Score
- (void)addScore:(NSString *)name withString:(NSString *)score;
- (void)parseScoreWithNSString:(NSString *)score;
- (void)parseScoreWithRTcmixScore:(RTcmixScore *)score;

// Singleton
+ (id)sharedManager;

// Playback and Interrupt Callbacks
static OSStatus rtcmixPerformCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags,
												  const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber,
												  UInt32 inNumberFrames, AudioBufferList *ioData);
void interruptionListenerCallback(void *inUserData, UInt32 interruptionState);
void propListenerCallback(void *inClientData, AudioSessionPropertyID inID,
								  UInt32 inDataSize,const void *inData);

@end

@protocol RTcmixPlayerDelegate
@optional
- (void)maxBang;
- (void)maxMessage:(NSArray *)message;
- (void)maxError:(NSString *)error;
@end

