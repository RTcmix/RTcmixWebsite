//
//  RTcmixScore.m
//
//  Copyright 2009-2013 Brad Garton, Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "RTcmixScore.h"

@implementation RTcmixScore

@synthesize rtScore;
@synthesize parsedScore;
@synthesize parameterValues;
@synthesize parameterInlets;
@synthesize isSetup;
@synthesize isBangScript;

- (id)initWithNSString:(NSString *)score {
	if (self = [super init])
	{
		rtScore = [[NSString alloc] initWithString:score];
		[self setupParameters];
	}
	return self;
}

- (id)initWithScoreFile:(NSString *)score {
	if (self = [super init]) {
		rtScore = [[NSString alloc] initWithContentsOfFile:score encoding:NSUTF8StringEncoding error:NULL];
		[self setupParameters];
	}
	return self;
}

- (void)setupParameters {
	parsedScore = [[NSMutableArray alloc] init];
	parameterValues = [[NSMutableDictionary alloc] init];
	parameterInlets = [[NSMutableDictionary alloc] init];
	
	NSArray *scoreLines = [rtScore componentsSeparatedByString:@"\n"];
	NSInteger parsedCount = 0;
	
	[parsedScore addObject:@" "];
	
	for (NSString *line in scoreLines)
	{
		NSRange inletRange = [line rangeOfString:@"%#)"];
		NSRange varRange = [line rangeOfString:@"%#"];
		
		if (inletRange.location != NSNotFound)
		{
			//NSString *trimmedLine = [line stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			NSArray *subLine = [line componentsSeparatedByString:@"%#)"];
			NSString *lineSubText = [subLine objectAtIndex:0];
			NSArray *subVar = [line componentsSeparatedByString:@" "];
			NSString *variableName = [subVar objectAtIndex:0];
			NSString *currentRunningLine = [parsedScore objectAtIndex:parsedCount];
			
			NSString *inletString = [[subVar objectAtIndex:3] stringByReplacingOccurrencesOfString:@"," withString:@""];
			NSNumberFormatter *inletFormat = [[NSNumberFormatter alloc] init];
			[inletFormat setNumberStyle:NSNumberFormatterDecimalStyle];
			[inletFormat setAllowsFloats:NO];
			NSNumber *inletNumber = [inletFormat numberFromString:inletString];
			
			[parameterValues setObject:[NSNumber numberWithFloat:0.0] forKey:variableName];
			[parameterInlets setObject:inletNumber forKey:variableName];
			
			[parsedScore replaceObjectAtIndex:parsedCount withObject:[currentRunningLine stringByAppendingString:lineSubText]];
			[parsedScore addObject:variableName];
			[parsedScore addObject:@") \n"];
			parsedCount += 2;
		}
		else if (varRange.location != NSNotFound)
		{
			NSArray *subLine = [line componentsSeparatedByString:@"%#"];
			NSString *lineSubText = [subLine objectAtIndex:0];
			NSArray *subVar = [line componentsSeparatedByString:@" "];
			NSString *variableName = [subVar objectAtIndex:0];
			NSString *currentRunningLine = [parsedScore objectAtIndex:parsedCount];
			
			[parameterValues setObject:[NSNumber numberWithFloat:0.0] forKey:variableName];
			[parameterInlets setObject:[NSNumber numberWithInt:0] forKey:variableName];
			
			[parsedScore replaceObjectAtIndex:parsedCount withObject:[currentRunningLine stringByAppendingString:lineSubText]];
			[parsedScore addObject:variableName];
			[parsedScore addObject:@" \n"];
			parsedCount += 2;
		}
		else
		{
			NSString *currentRunningLine = [parsedScore objectAtIndex:parsedCount];
			[parsedScore replaceObjectAtIndex:parsedCount withObject:[currentRunningLine stringByAppendingFormat:@"%@ \n", line]];
		}
	}
	[parameterValues setObject:[NSNumber numberWithInt:0] forKey:@"Touch"];
	[parameterInlets setObject:[NSNumber numberWithInt:0] forKey:@"Touch"];
}


@end
