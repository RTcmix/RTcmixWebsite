//
//  MessagesViewController.h
//  iRTcmix Lab
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import <UIKit/UIKit.h>
#import "RTcmixPlayer.h"

// Note that we've added <RTcmixPlayerDelegate> method here. This will allow
// us to implement the maxBang, maxMessage:, and maxError: delegate methods.
@interface MessagesViewController : UIViewController <RTcmixPlayerDelegate>

@property (nonatomic, strong)				RTcmixPlayer		*rtcmixManager;
@property (nonatomic, strong) IBOutlet UITextView			*textArea;
@property (nonatomic, strong)				NSMutableString	*errorMessage;
@property (nonatomic)						BOOL					bangLoop;
@property (nonatomic)						BOOL					messageLoop;

-(IBAction)goBang;
-(IBAction)toggleBangLoop:(UISwitch *)toggle;
-(IBAction)goMessage;
-(IBAction)toggleMessageLoop:(UISwitch *)toggle;
-(IBAction)goError;

@end
