//
//  AppDelegate.m
//  iRTcmix Lab
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "AppDelegate.h"

#import "BasicsViewController.h"
#import "SoundfilesViewController.h"
#import "InteractViewController.h"
#import "MessagesViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	
	// This initiallizes the RTcmixPlayer. Since it is a singleton class, there will only be one instance, shared by all.
	self.rtcmixManager = [RTcmixPlayer sharedManager];

	// Set up our ViewControllers and start the app up.
	UIViewController *viewController1 = [[BasicsViewController alloc] initWithNibName:@"BasicsViewController" bundle:nil];
	UIViewController *viewController2 = [[SoundfilesViewController alloc] initWithNibName:@"SoundfilesViewController" bundle:nil];
	UIViewController *viewController3 = [[InteractViewController alloc] initWithNibName:@"InteractViewController" bundle:nil];
	UIViewController *viewController4 = [[MessagesViewController alloc] initWithNibName:@"MessagesViewController" bundle:nil];
	self.tabBarController = [[UITabBarController alloc] init];
	self.tabBarController.viewControllers = @[viewController1, viewController2, viewController3, viewController4];
	self.window.rootViewController = self.tabBarController;
	[self.window makeKeyAndVisible];
	return YES;
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// If background mode is not enabled, pause the audio when the app enters the background.
	if (!self.rtcmixManager.shouldRunInBackground)
		[self.rtcmixManager pauseAudio];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// If background mode is not enabled (and thus audio would still be playing), restart the audio when the app
	// re-enters the foreground.
	if (!self.rtcmixManager.shouldRunInBackground)
		[self.rtcmixManager resumeAudio];
}

@end

