//
//  ViewController.m
//  User Input
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "ViewController.h"


@implementation ViewController


- (IBAction)filterFreqSlide:(UISlider *)sender {
	float freqValue = sender.value;
	NSNumber *freqObject = [NSNumber numberWithFloat:freqValue];
	
	// "filterFreq" is a 'PField' variable so it's value gets changed as the score plays
	[self.setupScore.parameterValues setObject:freqObject forKey:@"filterFreq"];
	[self.rtcmixManager setInlet:1 withValue:freqValue];
	
	[self.filterFreqLabel setText:[NSString stringWithFormat:@"%.2f", freqValue]];
}

- (IBAction)durationSlide:(UISlider *)sender {
	float durationValue = sender.value;
	NSNumber *durationObject = [NSNumber numberWithFloat:durationValue];
	
	// "dur" is a 'regular' variable so it's value won't change until the next time
	// the score is executed
	[self.mainScore.parameterValues setObject:durationObject forKey:@"dur"];
	
	[self.durationLabel setText:[NSString stringWithFormat:@"%.2f", durationValue]];
}

-(IBAction)goScore {
	[self.rtcmixManager parseScoreWithRTcmixScore:self.mainScore];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	
	// initialize the RTcmixPlayer and start audio
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	[self.rtcmixManager startAudio];
	
	// load the "setup" score from the file RTUserInput_Main.sco
	NSString *setupScorePath = [[NSBundle mainBundle] pathForResource:@"UserInput_Setup" ofType:@"sco"];
	NSString *setupScoreText = [NSString stringWithContentsOfFile:setupScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"UserInput_Setup" withString:setupScoreText];
	
	// load the "main" score from the file RTUserInput_Main.sco
	NSString *mainScorePath = [[NSBundle mainBundle] pathForResource:@"UserInput_Main" ofType:@"sco"];
	NSString *mainScoreText = [NSString stringWithContentsOfFile:mainScorePath encoding:NSUTF8StringEncoding error:nil];
	[self.rtcmixManager addScore:@"UserInput_Main" withString:mainScoreText];
	
	self.mainScore = [self.rtcmixManager.scoreDict objectForKey:@"UserInput_Main"];
	self.setupScore = [self.rtcmixManager.scoreDict objectForKey:@"UserInput_Setup"];
	
	// initialize default values of the variables
	// the RTcmixScore class looks for variables in the score that are assigned a value of "%#"
	// these variables can then be assigned values from your app - as in the next two lines
	[self.mainScore.parameterValues setObject:[NSNumber numberWithFloat:.25] forKey:@"dur"];
	[self.setupScore.parameterValues setObject:[NSNumber numberWithFloat:4000.0] forKey:@"filterFreq"];
	
	// run setup score
	[self.rtcmixManager parseScoreWithRTcmixScore:self.setupScore];
}


@end
