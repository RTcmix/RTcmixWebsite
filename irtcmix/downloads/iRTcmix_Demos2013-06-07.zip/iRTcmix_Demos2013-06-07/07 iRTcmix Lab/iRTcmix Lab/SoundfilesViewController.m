//
//  SoundfilesViewController.m
//  iRTcmix Lab
//
//  Copyright 2013 Damon Holzborn
//
//  This file is part of iRTcmix.
//
//  iRTcmix is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, version 3 of the License.
//
//  iRTcmix is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with iRTcmix.  If not, see <http://www.gnu.org/licenses/>.
//

#import "SoundfilesViewController.h"

@implementation SoundfilesViewController

-(IBAction)goRuff{	
	// Send the score to RTcmix to make some noise!
	[self.rtcmixManager parseScoreWithNSString:self.ruffScore];
}

-(IBAction)goHammer{
	// Send the score to RTcmix to make some noise!
	[self.rtcmixManager parseScoreWithNSString:self.hammerScore];
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
	
	// Initialize the RTcmixPlayer. Since audio has already been started in the BasicsViewController,
	// we don't have to do it again. Here we're just giving ourselves a pointer to the singleton object.
	self.rtcmixManager = [RTcmixPlayer sharedManager];
	
	// Load the sample buffer for the file we will play from RAM.
	[self.rtcmixManager setSampleBuffer:@"Loocher" withSoundFile:@"loocher441.aif"];
	
	// Get the path to the file we'll play from "disk."
	NSString *hammerPath = [[NSBundle mainBundle] pathForResource:@"AdamsJackhammer" ofType:@"aif"];
	
	// Set the RTcmix score strings.
	self.ruffScore = @"rtinput(\"MMBUF\", \"Loocher\") STEREO(0, 0, 9.971, .4, 0, 1)";
	self.hammerScore = [NSString stringWithFormat:@"rtinput(\"%@\") STEREO(0, 0, 17.63, .4, 0, 1)", hammerPath];
	
	// Load the Loocher Image.
	[self.loocherView setImage:[UIImage imageNamed: @"newlooch.png"]];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		self.title = NSLocalizedString(@"Soundfiles", @"Soundfiles");
		self.tabBarItem.image = [UIImage imageNamed:@"soundfiles"];
	}
	return self;
}

@end
